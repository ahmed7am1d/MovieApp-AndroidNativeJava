package cz.utb.fai.movieappal_doori;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
//import android.widget.SearchView;
import androidx.appcompat.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import cz.utb.fai.movieappal_doori.ViewModels.MovieListViewModel;
import cz.utb.fai.movieappal_doori.adapters.MovieRecyclerView;
import cz.utb.fai.movieappal_doori.adapters.OnMovieListener;
import cz.utb.fai.movieappal_doori.models.Movie;
import cz.utb.fai.movieappal_doori.request.Servicey;
import cz.utb.fai.movieappal_doori.response.MovieSearchResponse;
import cz.utb.fai.movieappal_doori.utils.Credentials;
import cz.utb.fai.movieappal_doori.utils.MovieApi;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MovieListActivity extends AppCompatActivity implements OnMovieListener {
    //Before we run our app, we need to add the network Secuirty config to allow subdomains
    //RecyclerView
    private RecyclerView recyclerView;
    private MovieRecyclerView movieRecyclerViewAdapter;


    //ViewModel
    private MovieListViewModel movieListViewModel;


    //Thread for the splash screen
    Thread Timer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //chaning the color of the action bar text
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Searchview
        //take the input from the user
        SetupSearchView();
        recyclerView = findViewById(R.id.recyclerView);
        movieListViewModel = new ViewModelProvider(this).get(MovieListViewModel.class);
        ConfigureRecyclerView();
        //Calling the observer
        ObserverAnyChange();
        //Bringing last search of the user using local storage
        String oldUserSearchQuery =  getData("userSearch");
        movieListViewModel.searchMovieApi(oldUserSearchQuery,1);
    }

    //we need observer in the main activity
    //to observe for any changes in the data for purpose of the view mode

    private void ObserverAnyChange() {
        movieListViewModel.getMovies().observe(this, new Observer<List<Movie>>() {
            @Override
            public void onChanged(List<Movie> movies) {
                //Observing for any data change
                if(movies != null ){
                    for(Movie movie: movies) {
                        Log.v("Tag", "[onChanged] The Title of the Movie: " + movie.getTitle());


                        movieRecyclerViewAdapter.setmMovies(movies);
                    }
                }
            }
        });
    }


    //-- Initializing the recycle view & adding data to it
    private void ConfigureRecyclerView() {
        //Live Data can't be passed via constructor
        movieRecyclerViewAdapter = new MovieRecyclerView(this);
        recyclerView.setAdapter(movieRecyclerViewAdapter);
        //Trying to use grid
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this,2,GridLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(gridLayoutManager);
        //recyclerView.setLayoutManager(new LinearLayoutManager((this)));


        //RecycleView pagination
        //we want to display all the pages when user hit the end of the page we update to the next page
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
             //when user had reched the button
                if(!recyclerView.canScrollVertically(1)) {
                    //Here we update the search query for next page
                    movieListViewModel.searchNextPage();
                }
            }
        });
    }


    @Override
      public void onMovieClick(int position) {
        //Toast.makeText(this,"This Position" + position , Toast.LENGTH_SHORT).show();
        //We don't need the position of the movie in the recycler view
        //we need to save or pass the id of the cliked movie in order to send it to details and bring from the api
        Intent intent = new Intent(this,MovieDetails.class);
        intent.putExtra("movie",movieRecyclerViewAdapter.getSelectedMovie(position));
        startActivity(intent);
    }

    @Override
    public void onCategoryClick(String category) {

    }

    //Get data from the user[SearchView]and use it to update the live data
    private void SetupSearchView() {
        final SearchView searchView = (SearchView) findViewById(R.id.search_view);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                //setup local storage for the search movie so next time when app loaded we bring it

                saveData("userSearch",query);

                movieListViewModel.searchMovieApi(
                        //The Search String getted from searchView
                        query,
                        1
                );
                return  false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                //Add here for dynamic typing of the search view listerner
                return false;
            }
        });
    }


    //Method to saveData to local storage
    private void saveData(String key, String value) {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPref",0);
        SharedPreferences.Editor  editor = sharedPreferences.edit();
        editor.putString(key,value);
        editor.apply();
    }


    //Method to getData from local storage
    private String getData(String key) {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPref",0);
        if(sharedPreferences.contains(key)) {
        String data = sharedPreferences.getString(key,null);
        return data;
        }else {
            return "Friends";
        }

    }

}


