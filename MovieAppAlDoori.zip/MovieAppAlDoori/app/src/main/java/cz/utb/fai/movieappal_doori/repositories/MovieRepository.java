package cz.utb.fai.movieappal_doori.repositories;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.List;

import cz.utb.fai.movieappal_doori.models.Movie;
import cz.utb.fai.movieappal_doori.request.MovieApiClient;
//This class implement the concept of signleton pattern

public class MovieRepository {
    //This class is acting as repositories
    private static MovieRepository instance;

    private MovieApiClient movieApiClient;

    private String mQuery;
    private int mPageNumber;

    public static MovieRepository getInstance() {
    if(instance == null) {
        instance = new MovieRepository();
    }
    return  instance;
    }
    private MovieRepository() {
        movieApiClient = MovieApiClient.getInstance();
    }
    public LiveData<List<Movie>> getMovies() {
        return  movieApiClient.getMovies();
    }


    //Calling the method in repository
    public void searchMovieApi(String query,int pageNumber){
    //remeber this method is in the MovieApiClient and it will populate the live data

    mQuery = query;
    mPageNumber = pageNumber;
    movieApiClient.searchMovieApi(query,pageNumber);
    }

    public void searchNextPage() {
        searchMovieApi(mQuery,mPageNumber +1 );
    }

}

