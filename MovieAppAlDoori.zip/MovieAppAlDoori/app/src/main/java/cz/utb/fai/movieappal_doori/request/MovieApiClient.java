package cz.utb.fai.movieappal_doori.request;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import cz.utb.fai.movieappal_doori.AppExecutors;
import cz.utb.fai.movieappal_doori.models.Movie;
import cz.utb.fai.movieappal_doori.response.MovieSearchResponse;
import cz.utb.fai.movieappal_doori.utils.Credentials;
import retrofit2.Call;
import retrofit2.Response;

//Last Step => all of our live data will be inside the Movie API Client
public class MovieApiClient {

    //#region 1- LiveData and Singleton Pattern instilization

    //MutableLiveData => act like live data  [because we have live data inside our view model ]
    private MutableLiveData<List<Movie>> mMovies ;
    private static MovieApiClient instance;

    public static MovieApiClient getInstance(){
        if(instance == null)
            instance = new MovieApiClient();
        return instance;
    }
    //#endregion

    //#region 2- Constructor
    private MovieApiClient() {
    mMovies = new MutableLiveData<>();
}
    //#endregion


    //making global Runnable


    public LiveData<List<Movie>> getMovies() {
        return mMovies;
    }

    private RetrieveMoviesRunnable retrieveMoviesRunnable;
    //This method that we are going to call through the classes
    //This method uses the threading idea
    public void searchMovieApi(String query, int pageNumber) {

        if(retrieveMoviesRunnable != null) {
            retrieveMoviesRunnable = null;
        }
        retrieveMoviesRunnable = new RetrieveMoviesRunnable(query,pageNumber);

        final Future myHandler = AppExecutors.getInstance().networkIO().submit(retrieveMoviesRunnable);
        AppExecutors.getInstance().networkIO().schedule(new Runnable() {
            @Override
            public void run() {
                //Cacelling the retrofit call [TimeOut]
                //To avoid any app crashes
                //in 4 second if we did not get the request we will cancel it
                myHandler.cancel(true);
            }
        },3000, TimeUnit.MILLISECONDS);
    }



    //Retriving data from RESTAPI by runnable class
    //We have 2 types of queries : The ID & search Queries
    private class RetrieveMoviesRunnable implements Runnable {

        private String query;
        private int pageNumber;
        boolean cancelRequest;

        //Constructor
        public RetrieveMoviesRunnable(String query, int pageNumber) {
            this.query = query;
            this.pageNumber = pageNumber;
            this.cancelRequest = false;
        }



        @Override
        public void run() {
            //Getting the response objects

            try {
                Response response = getMovies(query,pageNumber).execute();
                if(cancelRequest) {
                    return;
                }
                if(response.code() == 200) {
                    List<Movie> movieList = new ArrayList<>(((MovieSearchResponse) response.body()).getMovies());
                    if(pageNumber == 1) {
                        //Sending data to live data
                        //PostValue: used for background thread
                        //setValue: not for background thread
                        mMovies.postValue(movieList);
                    }
                    else {
                        List<Movie> currentMovies = mMovies.getValue();
                        currentMovies.addAll(movieList);
                        mMovies.postValue(currentMovies);
                    }
                }
                else {
                    String error = response.errorBody().string();
                    Log.v("Tag","Error: "+ error);
                    mMovies.postValue(null);
                }
            } catch (IOException e) {
                e.printStackTrace();
                mMovies.postValue(null);
            }


        }
            //Search Method/Query
            private Call<MovieSearchResponse> getMovies(String query, int pageNumber) {
                return Servicey.getMovieApi().searchMovie(
                        Credentials.API_KEY,
                        query,
                        pageNumber
                );
            }
            //Cancel Request Method
            private  void cancelRequest() {
                Log.v("Tag","Cancelling Search Request");
                cancelRequest = true;

        }
    }

}
