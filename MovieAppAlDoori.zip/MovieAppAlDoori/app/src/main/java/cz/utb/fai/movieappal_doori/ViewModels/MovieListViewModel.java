package cz.utb.fai.movieappal_doori.ViewModels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import cz.utb.fai.movieappal_doori.models.Movie;
import cz.utb.fai.movieappal_doori.repositories.MovieRepository;

//This class is used for viewmodel
public class MovieListViewModel extends ViewModel {

    private MovieRepository movieRepository;

    //Constructor
    public MovieListViewModel() {
        movieRepository = MovieRepository.getInstance();
    }

    //Getter
    public LiveData<List<Movie>> getMovies() {
        return movieRepository.getMovies() ;
    }
    //Calling method in the view-model [method for query]
    //Remember the architecture (MVVM)
    public void searchMovieApi(String query, int pageNumber) {
        movieRepository.searchMovieApi(query,pageNumber);
    }

    public void searchNextPage() {
        movieRepository.searchNextPage();
    }
}
