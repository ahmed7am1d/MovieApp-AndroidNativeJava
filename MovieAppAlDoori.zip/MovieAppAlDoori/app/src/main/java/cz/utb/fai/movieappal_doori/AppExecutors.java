package cz.utb.fai.movieappal_doori;
//Purpose => Running the retrofit calls in the background
//the ExecutroService => are going to make calls using retrofit and webservice and store the result data in the LiveData :)
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class AppExecutors {
    //Singleton Pattern
    private static  AppExecutors instance;
    public static  AppExecutors getInstance() {
        if(instance == null)
            instance = new AppExecutors();
        return  instance;
    }

    private final ScheduledExecutorService mNetworkIO = Executors.newScheduledThreadPool(3);
    public ScheduledExecutorService networkIO() {
        return  mNetworkIO;
    }

}
