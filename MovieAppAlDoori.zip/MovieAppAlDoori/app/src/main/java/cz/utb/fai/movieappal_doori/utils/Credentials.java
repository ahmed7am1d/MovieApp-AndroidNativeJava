package cz.utb.fai.movieappal_doori.utils;

public class Credentials {
    public static final String BASE_URL = "https://api.themoviedb.org";
    public static final String API_KEY = "37e0a01b9ab739a80362d37aed4a6db6";

}
