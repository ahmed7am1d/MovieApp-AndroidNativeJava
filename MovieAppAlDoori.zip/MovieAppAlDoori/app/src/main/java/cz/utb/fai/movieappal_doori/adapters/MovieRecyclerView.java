package cz.utb.fai.movieappal_doori.adapters;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import cz.utb.fai.movieappal_doori.R;
import cz.utb.fai.movieappal_doori.models.Movie;

public class MovieRecyclerView extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<Movie> mMovies;
    private OnMovieListener onMovieListener;

    public MovieRecyclerView(OnMovieListener onMovieListener) {
        this.onMovieListener = onMovieListener;

    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.movie_list_item,parent,false);
        return  new MovieViewHolder(view,onMovieListener);
    }

    @Override
    //instead of creating new view for each new data an old view is recycled and reused by binding new data to it
    //this in case where old view is disappeard from the screen

    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int i) {

        ((MovieViewHolder)holder).title.setText(mMovies.get(i).getTitle());
        //((MovieViewHolder)holder).release_date.setText(mMovies.get(i).getRelease_date());
        //((MovieViewHolder)holder).duration.setText("" +mMovies.get(i).getOriginal_language());
        //Vote avg is over 10, and our rating bar has only 5 starts -- dividing by 2
        //((MovieViewHolder)holder).ratingBar.setRating((mMovies.get(i).getVote_average())/2);


        //ImageView: Using Glide Library
        Glide.with(holder.itemView.getContext())
                .load("https://image.tmdb.org/t/p/w500/"+mMovies.get(i).getPoster_path())
                .into(((MovieViewHolder) holder).imageView);
    }

    @Override
    public int getItemCount() {
        if(mMovies != null){
            return mMovies.size();
        }
    return 0;
    }

    public void setmMovies(List<Movie> mMovies) {
        this.mMovies = mMovies;
        notifyDataSetChanged();
    }

    //Getting the id of the movie clicked
    public Movie getSelectedMovie(int position) {
        if(mMovies != null) {
            if(mMovies.size() > 0 ) {
                return mMovies.get(position);
            }
        }
    return  null;
    }

}
