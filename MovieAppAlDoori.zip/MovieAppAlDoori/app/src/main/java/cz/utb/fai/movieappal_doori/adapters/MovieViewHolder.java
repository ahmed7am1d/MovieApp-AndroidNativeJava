package cz.utb.fai.movieappal_doori.adapters;

import android.media.Rating;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import cz.utb.fai.movieappal_doori.R;
//this movie holder contains the widgets and data of our layout that we created in layout ssection

public class MovieViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    //Widegts
    TextView title, release_date,duration;
    ImageView imageView;
    RatingBar ratingBar;

    //Click Listener
    OnMovieListener onMovieListener;

    public MovieViewHolder(@NonNull View itemView, OnMovieListener onMovieListener1) {
        super(itemView);
        this.onMovieListener = onMovieListener1;
        title = itemView.findViewById(R.id.movie_title) ;
        //release_date = itemView.findViewById(R.id.movie_category);
        //duration = itemView.findViewById(R.id.movie_duration);
        //ratingBar = itemView.findViewById(R.id.rating_bar);
        imageView = itemView.findViewById(R.id.movie_img);
        itemView.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        onMovieListener.onMovieClick(getAdapterPosition());
    }
}
