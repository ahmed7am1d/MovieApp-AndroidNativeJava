package cz.utb.fai.movieappal_doori.utils;

import cz.utb.fai.movieappal_doori.models.Movie;
import cz.utb.fai.movieappal_doori.response.MovieSearchResponse;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface MovieApi {

    //Search for movies
    //https://api.themoviedb.org/3/search/movie?api_key=37e0a01b9ab739a80362d37aed4a6db6&query=purge
    //Retrofit understand automatically and will know that path after https://api.themoviedb.org/ will be /search/movie
    //but we need to provide api key and search query :)
    @GET("/3/search/movie?")
    Call<MovieSearchResponse> searchMovie(
            @Query("api_key") String key,
            @Query("query") String query,
            @Query("page") int page
    );

    //Making Search with ID
    //https://api.themoviedb.org/3/movie/343611?api_key={api_key}

    @GET("/3/movie/{movie_id}?")
    Call<Movie> getMovie(
            @Path("movie_id") int movie_id,
            @Query("api_key") String api_key
    );



}
