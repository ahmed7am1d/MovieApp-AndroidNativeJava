package cz.utb.fai.movieappal_doori.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import cz.utb.fai.movieappal_doori.models.Movie;

//This class is for Single Movie Request :)
public class    MovieResponse {
    //[1] Finding the Movie Object
    //This telling retrofit that I will Serlized an array called results inside the request of the api when user search for a movie
    @SerializedName("results")
    @Expose
    private Movie movie;
    public Movie getMovie() {
        return  movie;
    }

    @Override
    public String toString() {
        return "MovieResponse{" +
                "movie=" + movie +
                '}';
    }
}
