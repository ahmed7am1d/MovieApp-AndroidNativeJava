package cz.utb.fai.movieappal_doori;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import cz.utb.fai.movieappal_doori.models.Movie;

public class MovieDetails extends AppCompatActivity {
    //Getting the widgets that we created in the design
    private ImageView imageViewDetails;
    private TextView titleDetails, descDetails;
    private RatingBar ratingBarDetails;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);

        //onCreate institiate the Widgets
        imageViewDetails = findViewById(R.id.imageViewDetails);
        titleDetails = findViewById(R.id.textView_title_details);
        descDetails = findViewById(R.id.textView_desc_details);
        ratingBarDetails = findViewById(R.id.ratingBar_details);


        GetDataFromInternet();

    }


    private void GetDataFromInternet() {
        if(getIntent().hasExtra("movie")){
            Movie movie = getIntent().getParcelableExtra("movie");
            titleDetails.setText(movie.getTitle());
            descDetails.setText(movie.getMovie_overview());
            ratingBarDetails.setRating(movie.getVote_average() / 2);

            Glide.with(this)
                    .load("https://image.tmdb.org/t/p/w500/" + movie.getPoster_path())
                    .into(imageViewDetails);
        }
    }
}
//1-